package com.example.signingoogle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.android.gms.common.GoogleSignatureVerifier;
import com.google.android.gms.common.SignInButton;

public class MainActivity extends AppCompatActivity {

    private SignInButton signInButton;
    private String TAG = "MainActivity";
    private FirebaseAu

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
